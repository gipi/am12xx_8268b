#!/bin/sh

filestring=""
filefolder="library_unstripped"
rm -rf $filefolder
mkdir $filefolder
for line in `find -name *.so-unstripped `; do
	filestring=`echo $line | awk '{last = split($0,array,"/")} {print array[last]}'`
	filestring=`echo $filestring | cut -d "-" -f1`
	echo $filestring
	cp $line ./$filefolder/$filestring
done
